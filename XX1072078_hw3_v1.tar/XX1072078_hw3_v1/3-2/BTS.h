#include <string>
using namespace std;

class BTS { 
public: 
    void Insertion(int n);
    void Deletion(int n);
    void key();
    void TreeSearch();
    void Max();
    void Min();
    void Successor();
    void Predecessor();

    
 
    double radius();
    string& name(); 
 
    void radius(double); 
    void name(const char*); 
    void name(string&); 
 
    double volumn(); 

};